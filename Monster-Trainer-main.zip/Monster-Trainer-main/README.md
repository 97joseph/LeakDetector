# Monster-Trainer
First attempt at using Dynamic Memory in C.
